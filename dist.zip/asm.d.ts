declare function rol(value: number, carry: boolean): {
    result: number;
    carry: boolean;
};

export { rol };
