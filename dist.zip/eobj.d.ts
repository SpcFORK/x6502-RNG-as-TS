declare function eobj<C extends Record<any, any> & unknown>(obj: C, names?: string[]): Record<any, C>;
declare const _default: typeof eobj;

export { _default as default };
